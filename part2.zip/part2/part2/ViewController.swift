//
//  ViewController.swift
//  part2
//
//  Created by 황효진 on 2019. 10. 23..
//  Copyright © 2019년 hyojin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet private weak var
    displayLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction private func didTapbutton(_ sender: UIButton){
        guard let input = sender.currentTitle
            else { return }
        print(input)
    }

    enum Command {
        case addDigit(String)
        case operation(String)
        case eqal
        case clear
    }
    
    @IBAction private func didTapButton(_ sender: UIButton){
        
        guard let input = sender.currentTitle else { return }
        
        let command: Command
        switch input {
        case "AC":
            command = .clear
        case "=":
            command = .eqal
        case "+", "-", "×","÷":
            command = .operation(input)
        default:
            command = .addDigit(input)
        }
    }
    
    private var displayValue: String{
        get { return displayLabel.text ?? "" }
        set { displayLabel.text = newValue }
    }
    
    private func performCommand(_ command: Command, with displayText: String) -> String {
        var result: Double?
        
        switch command {
        case .addDigit(let input):
            return addDigit(value: input, to: displayText)
        case .operation(let op):
            accumulater = calculate(for: displayText)
            bufferOperator = op
            result  = accumulater
        case .eqal:
            result = calculate(for: displayText)
            accumulater = 0
            bufferOperator = nil
        case .clear:
            accumulater = 0
            bufferOperator = nil
        }
        shouldResetText = true
        return String(result ?? 0)
    }
    
    private var shouldResetText = true
    private func addDigit(value newValue: String, to oldValue: String) -> String {
        let displayString = shouldResetText ? newValue
        : oldValue.count > 13 ? oldValue
        : oldValue + newValue
        
        shouldResetText = false
        return displayString
    }
    
    private var accumulater = 0.0
    private var bufferOperator: String?
    
    private func calculate(for newVaule: String) -> Double {
        let operand = Double(newVaule) !
        
        switch bufferOperator {
        case "+":
            return accumulater + operand
        case "-":
            return accumulater - operand
        case "×":
            return accumulater * operand
        case "÷":
            return accumulater / operand
        default:
            return operand
        }
    }

    
    private func limitFractionDigits(to numString: String) -> String {
        guard let number = Double(numString) else {
            return "0"
        }
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 3
        return formatter.string(from: number as NSNumber) ?? "0"
    }
}

